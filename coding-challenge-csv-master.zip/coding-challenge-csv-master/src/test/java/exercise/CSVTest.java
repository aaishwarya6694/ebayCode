package exercise;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class CSVTest {

    // your unit tests here
    PersonOperations personOperations = new PersonOperations();
    List<Person> personList = new ArrayList<>();
    @Test
    void shouldThrowFileNotFoundException(){
        CSVParser parser = new CSVParser();
        String fileName= "src/testdata/address-book1.csv";
        Assertions.assertThrows(FileNotFoundException.class,()->{
            parser.parseCSV(fileName);
        });
    }

    @Test
    void shouldAddPersonDataToList(){
        Person person = new Person("Jon",Gender.Male,new Date());
        personList= personOperations.addPerson(person,personList);
        Assertions.assertEquals(1,personList.size());
    }

    @Test
    void shouldReturnCorrectCountOfFemales(){
        personList.add(new Person("Larry",Gender.Male,new Date()));
        personList.add(new Person("Johnny",Gender.Male,new Date()));
        int count =  personOperations.countFemale(personList);
        Assertions.assertEquals(0,count);
    }

    @Test
    void checkForIncorrectCountOfFemales(){
        personList.add(new Person("Andy",Gender.Male,new Date()));
        int count =  personOperations.countFemale(personList);
        Assertions.assertNotEquals(1,count);
    }

    @Test
    void shouldCheckForCorrectOldestPerson() throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        personList.add(new Person("Oliver",Gender.Male,format.parse("1979-04-20")));
        Person person = personOperations.findOldestPerson(personList);
        Assertions.assertEquals("Oliver",personList.get(0).getName());
    }

    @Test
    void shouldCheckForInCorrectOldestPerson() throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        personList.add(new Person("Oliver",Gender.Male,format.parse("1979-04-20")));
        Person person = personOperations.findOldestPerson(personList);
        Assertions.assertNotEquals("Andy",personList.get(0).getName());
    }

    @Test
    void shouldCheckIfFileIsNotEmpty() throws IOException, ParseException {
        CSVParser parser = new CSVParser();
        String fileName= "src/testdata/address-book.csv";
        personList=parser.parseCSV(fileName);
        Assertions.assertTrue(personList.size()>0);
    }

    @Test
    void shouldThrowParseExceptionForDate(){
        String[] personValues = {"Ash","Female","1978/03/23"};
        Assertions.assertThrows(ParseException.class,()->{
            personOperations.stringToPerson(personValues);
        });
    }

    @Test
    void shouldNotAddPersonIfNameIsEmpty(){
        Person person = new Person(" ",Gender.Male,new Date());
        personList= personOperations.addPerson(person,personList);
        Assertions.assertNotEquals(0,personList.size());
    }

}
