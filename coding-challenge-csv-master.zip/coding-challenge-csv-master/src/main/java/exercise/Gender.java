package exercise;

public enum Gender {
    Male,Female
}
