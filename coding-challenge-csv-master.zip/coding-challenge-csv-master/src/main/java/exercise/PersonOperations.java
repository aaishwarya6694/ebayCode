package exercise;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.List;

public class PersonOperations {

    public int countFemale(List<Person> personList){
        int count=0;
        for(Person p:personList){
            if(p.getGender()!=null && p.getGender().equals(Gender.Female)) {
                count++;
            }
        }
        return count;
    }

    public Person findOldestPerson(List<Person> personList){
        personList.sort(Comparator.comparing(Person::getDateOfBirth));
        if(personList.size()!=0)
            return personList.get(0);
        else
            return new Person();
    }

    public List<Person> addPerson(Person person,List<Person> personList){
        if(person!=null && person.getDateOfBirth()!=null && !person.getName().isEmpty() && person.getGender()!=null){
            personList.add(person);
        }
        return personList;
    }

    public Person stringToPerson(String[] personData) throws ParseException {
        Person person = new Person();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        if(personData[0]!=null){
            person.setName(personData[0]);
        }
        if(!personData[1].isBlank()){
            if(personData[1].charAt(1)!=' ' && (personData[1].charAt(1)=='F'|| personData[1].charAt(1)=='f') )
            {
                person.setGender(Gender.Female);
            } else{
                person.setGender(Gender.Male);
            }
        }
        if(personData.length>2){  //check if date is present on the line
            if(personData[2]!=null){
                person.setDateOfBirth(format.parse(personData[2]));
            }
        }
        return person;
    }
}
