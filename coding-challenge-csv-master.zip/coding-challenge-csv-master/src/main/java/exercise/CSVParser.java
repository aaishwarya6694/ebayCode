package exercise;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


public class CSVParser {


    public List<Person> parseCSV(String filename) throws IOException, ParseException {
        String DELIMITER = ",";
        List<Person> personList = new ArrayList<>();

        PersonOperations personOperations=new PersonOperations();
            BufferedReader bufferedReader = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] values = line.split(DELIMITER);
                Person person = personOperations.stringToPerson(values);
                personList= personOperations.addPerson(person,personList);
            }

        return personList;
    }


}
