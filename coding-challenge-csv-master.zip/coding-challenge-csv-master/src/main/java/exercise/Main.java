package exercise;


import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class Main {


    public static void main(String[] args) throws IOException, ParseException {
        String fileName = "src/testdata/address-book.csv";
        CSVParser parser = new CSVParser();
        List<Person> personList = parser.parseCSV(fileName);
        PersonOperations personOperations = new PersonOperations();
        int countOfFemales = personOperations.countFemale(personList);
        System.out.println("Number of females inside address book:"+countOfFemales);

        Person oldestPerson = personOperations.findOldestPerson(personList);
        System.out.println("Oldest person inside address book:"+oldestPerson.toString());

    }

}
